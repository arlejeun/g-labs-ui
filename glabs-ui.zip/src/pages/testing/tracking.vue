<script setup lang="ts">

</script>

<template>

  <HelloI18n/>
  <div class="container">
	<Analytics/>
  </div>
 
</template>

<route lang="yaml">
meta:
  layout: BasicTopNavigationLayout
</route>

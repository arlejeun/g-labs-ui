<script setup lang="ts">
const router = useRouter()

onMounted(() => {
  router.push('/sidebar/dashboards')
})
</script>

<template>
  <div></div>
</template>

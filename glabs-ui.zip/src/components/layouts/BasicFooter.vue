<script setup lang="ts">
</script>

<template>
  <div class="container">
          <div class="row align-items-center">
            <div class="col-md-4">
              <div class="text-center text-md-start mb-3 mb-md-0">
                <a href="index.html"> <img class="h-30px" src="@/assets/images/genesys_monogram_detail.svg" alt="logo">
                </a>
              </div>
            </div>

            <!-- Widget -->
            <div class="col-md-6">
              <div class="text-white text-primary-hover"> Copyrights <a href="#" class="text-white">©2022 Genesys
                  Drive</a>. All rights reserved. </div>
            </div>

            <!-- Widget -->
            <div class="col-md-4">
              <ul class="list-inline mb-0 text-center text-md-end">
                <li class="list-inline-item ms-2"><a href="#"><i class="text-white fab fa-facebook"></i></a></li>
                <li class="list-inline-item ms-2"><a href="#"><i class="text-white fab fa-instagram"></i></a></li>
                <li class="list-inline-item ms-2"><a href="#"><i class="text-white fab fa-linkedin-in"></i></a></li>
                <li class="list-inline-item ms-2"><a href="#"><i class="text-white fab fa-twitter"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
  <!-- Sidebar END -->
</template>

<style>

</style>
